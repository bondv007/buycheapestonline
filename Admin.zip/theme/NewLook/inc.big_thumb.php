<div class="right_box">
    <div class="right_box_top"></div>
    <div class="right_box_inn">
        <br />
        <a href="<?php echo base_url ?>s/<?php echo $website["WebsiteID"] ?>/" target="_blank" rel="nofollow">
           <img id="bigThumb" src="<?php echo pic_url."pic240/".str_replace(".","-",strtolower($website['WebsiteTitle'])).".jpg" ?>" alt="<?php echo $website["WebsiteName"] ?>" />
        </a>
        <br />
        <a href="<?php echo base_url ?>s/<?php echo $website["WebsiteID"] ?>/" target="_blank" rel="nofollow">Shop <?php echo $website["WebsiteTitle"] ?> &raquo;</a>
    </div>
    <div class="right_box_bottom"></div>                	
</div>
