<div id="search">
    <form id="searchForm" method="post" action="<?php echo base_url ?>srch_query/">
    <input name="query" type="text" class="search_area" />
    <input type="submit" class="search_btn" />
    </form>
</div>
