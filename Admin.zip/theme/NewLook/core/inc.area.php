<div style="padding: 15px;">
	<div id="otherareas">
		Other Areas:
		<li>
			<a href="http://atlanta.kijiji.com/" title="Free Atlanta Classifieds">
				Atlanta
			</a>
		</li>
		<li>
			<a href="http://boston.kijiji.com/" title="Free Boston Classifieds">
				Boston
			</a>
		</li>
		<li>
			<a href="http://charlotte.kijiji.com/" title="Free Charlotte Classifieds">
				Charlotte
			</a>
		</li>
		<li>
			<a href="http://chicago.kijiji.com/" title="Free Chicago Classifieds">
				Chicago
			</a>
		</li>
		<li>
			<a href="http://dallas.kijiji.com/" title="Free Dallas Classifieds">
				Dallas
			</a>
		</li>
		<li>
			<a href="http://denver.kijiji.com/" title="Free Denver Classifieds">
				Denver
			</a>
		</li>
		<li>
			<a href="http://detroit.kijiji.com/" title="Free Detroit Classifieds">
				Detroit
			</a>
		</li>
		<li>
			<a href="http://houston.kijiji.com/" title="Free Houston Classifieds">
				Houston
			</a>
		</li>
		<li>
			<a href="http://indianapolis.kijiji.com/" title="Free Indianapolis Classifieds">
				Indianapolis
			</a>
		</li>
		<li>
			<a href="http://losangeles.kijiji.com/" title="Free Los Angeles Classifieds">
				Los Angeles
			</a>
		</li>
		<li>
			<a href="http://miami.kijiji.com/" title="Free Miami Classifieds">
				Miami
			</a>
		</li>
		<li>
			<a href="http://minneapolisstpaul.kijiji.com/" title="Free Twin Cities Classifieds">
				Minneapolis / St. Paul
			</a>
		</li>
		<li>
			<a href="http://newyork.kijiji.com/" title="Free New York Classifieds">
				New York
			</a>
		</li>
		<li>
			<a href="http://orlando.kijiji.com/" title="Free Orlando Classifieds">
				Orlando
			</a>
		</li>
		<li>
			<a href="http://phoenix.kijiji.com/" title="Free Phoenix Classifieds">
				Phoenix
			</a>
		</li>
		<li>
			<a href="http://pittsburgh.ebayclassifieds.com/" title="Free Pittsburgh Classifieds">
				Pittsburgh
			</a>
		</li>
		<li>
			<a href="http://portlandor.kijiji.com/" title="Free Portland, OR, Classifieds">
				Portland, OR
			</a>
		</li>
		<li>
			<a href="http://raleigh.kijiji.com/" title="Free Raleigh Classifieds">
				Raleigh
			</a>
		</li>
		<li>
			<a href="http://sanantonio.ebayclassifieds.com/" title="Free San Antonio Classifieds">
				San Antonio
			</a>
		</li>
		<li>
			<a href="http://sandiego.kijiji.com/" title="Free San Diego Classifieds">
				San Diego
			</a>
		</li>
		<li>
			<a href="http://seattle.kijiji.com/" title="Free Seattle Classifieds">
				Seattle
			</a>
		</li>
		<li>
			<a href="http://bayarea.kijiji.com/" title="Free San Francisco Bay Area Classifieds">
				San Francisco Bay Area
			</a>
		</li>
		<li>
			<a href="http://stlouis.kijiji.com/" title="Free St. Louis Classifieds">
				St. Louis
			</a>
		</li>
		<li>
			<a href="http://tampabay.kijiji.com/" title="Free Tampa Bay Classifieds">
				Tampa Bay
			</a>
		</li>
		<li>
			<a href="http://washingtondc.kijiji.com/" title="Free Washington DC Classifieds">
				Washington DC
			</a>
		</li>
		<li>
			<a href="http://www.kijiji.com/?ChangeLocation=Y" style="text-decoration: underline;" title="Other Free US Classifieds">
				(more)
			</a>
		</li>
	</div>
</div>
