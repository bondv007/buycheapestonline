<?php
	
	include_once ( "../classes/data_validation.php" ) ;
	
	$pageSize = 15 ;
	
	
?>