<?php
	
	include ( "theme/".$app_init_data["CurrentSkin"]."/home.php" ) ;

?>