<?php 
 define ( base_url , 'http://www.buycheapestonline.com/' ) ; 
 define ( DBSERVER , 'localhost' ) ; 
 define ( DBNAME , 'buychea1_buychea1' ) ; 
 define ( DBUSERNAME , 'buychea1_buychea' ) ; 
 define ( DBPASSWORD , 'vs~4tmuwOJu2' ) ;
 define ( pic_url , 'http://www.domain.com/media/' ) ;  
 define ( URLPOSTFIX , '.htm' ) ; 
 define ( UPLOADPATH , 'offers' ) ; 
 error_reporting(E_ALL & ~E_NOTICE);
?>